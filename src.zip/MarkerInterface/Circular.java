
package pp.MarkerInterface;

public class Circular extends Documento
        implements Imprimivel, Confidencial
{
	public Circular( String texto )
	{
		super( texto );
	}
}
