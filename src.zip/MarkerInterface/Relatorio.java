
package pp.MarkerInterface;

public class Relatorio extends Documento
        implements Imprimivel, Comprimivel
{
	public Relatorio( String texto )
	{
		super( texto );
	}
}
