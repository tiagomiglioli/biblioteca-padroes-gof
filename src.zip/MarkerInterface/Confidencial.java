
package pp.MarkerInterface;

public interface Confidencial {

}
