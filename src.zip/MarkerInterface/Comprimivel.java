
package pp.MarkerInterface;

public interface Comprimivel {

}
