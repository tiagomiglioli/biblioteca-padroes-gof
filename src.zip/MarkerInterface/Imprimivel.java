
package pp.MarkerInterface;

public interface Imprimivel {

}
