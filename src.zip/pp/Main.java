
package pp;

public class Main
{
    public static void main(String args[])
    {
        pp.MarkerInterface.Teste.execute();
        pp.Adapter.Teste.execute();
        pp.composite.Teste.execute();
        pp.composite.Teste.execute1();      
        pp.composite.arquivo.Teste.execute();

        pp.Delegation.Teste.execute();

        pp.MethodFactory.Teste.execute();
        pp.MethodFactory.Pizzaria.Teste.execute();

        pp.Singleton.Teste.execute();

        pp.decorator.Teste.execute();
    }
}
