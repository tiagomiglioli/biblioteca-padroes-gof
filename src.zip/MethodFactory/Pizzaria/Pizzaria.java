
package pp.MethodFactory.Pizzaria;

abstract public class Pizzaria
{
    abstract public Pizza createPizza(String type);
}
