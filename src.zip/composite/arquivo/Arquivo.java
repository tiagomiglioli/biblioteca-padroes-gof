package pp.composite.arquivo;

class Arquivo extends ComponenteSistemaArquivos {

    private String texto;

    public Arquivo(String nome, String texto) {
        super(nome);
        this.texto = texto;
    }

    public void exibir_nome() {
        System.out.println("ARQUIVO : " + nome);
    }

    public void exibir_conteudo() {
        System.out.println("CONTEUDO: " + texto);
    }

    public void listar_recursivo(int nivel) {
        tabular(nivel);
        exibir_nome();
    }
}
