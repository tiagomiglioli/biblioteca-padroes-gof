package pp.composite.arquivo;

import java.util.Vector;

class Pasta extends ComponenteSistemaArquivos {

    private Vector componentes;

    public Pasta(String nome) {
        super(nome);
        componentes = new Vector();
    }

    public void add(ComponenteSistemaArquivos c) {
        componentes.add(c);
    }

    public void exibir_nome() {
        System.out.println("PASTA   : " + nome);
    }

    public void exibir_conteudo() {
        for (int i = 0; i < componentes.size(); i++) {
            ((ComponenteSistemaArquivos) componentes.elementAt(i)).exibir_nome();
        }
    }

    public void listar_recursivo(int nivel) {
        tabular(nivel);
        exibir_nome();
        for (int i = 0; i < componentes.size(); i++) {
            ((ComponenteSistemaArquivos) componentes.elementAt(i)).listar_recursivo(nivel + 1);
        }
    }
}
