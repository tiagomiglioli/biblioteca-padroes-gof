
package pp.composite;

abstract public class Expressao
{
    abstract public double calcular();
    abstract public String toString();
}
