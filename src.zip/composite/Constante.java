
package pp.composite;

public class Constante extends Operando
{
    public Constante(double valor)
    {
        super( valor );
    }
}
