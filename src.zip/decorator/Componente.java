
package pp.decorator;

abstract interface Componente
{
   void desenha();
} 